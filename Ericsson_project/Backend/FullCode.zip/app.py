from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, IntegerField
from wtforms.validators import DataRequired, Email, Length, EqualTo
from flask_session import Session
from dotenv import load_dotenv
import os
import mysql.connector

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Database connection
db_config = {
    'host': os.getenv('DB_HOST'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME')
}

# Database functions
def get_db_connection():
    return mysql.connector.connect(db_config)

def get_buses(source, destination, date):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT  FROM buses WHERE source = %s AND destination = %s AND departure_date = %s",
        (source, destination, date)
    )
    buses = cursor.fetchall()
    conn.close()
    return buses

def get_bus_details(bus_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT  FROM buses WHERE bus_id = %s",
        (bus_id,)
    )
    bus = cursor.fetchone()
    conn.close()
    return bus

def book_ticket(bus_id, user_id, seats):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO bookings (bus_id, user_id, seats, booking_date) VALUES (%s, %s, %s, NOW())",
        (bus_id, user_id, seats)
    )
    conn.commit()
    conn.close()

# Forms
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class SearchForm(FlaskForm):
    source = SelectField('Source', choices=[], validators=[DataRequired()])
    destination = SelectField('Destination', choices=[], validators=[DataRequired()])
    date = StringField('Date', validators=[DataRequired()])
    submit = SubmitField('Search')

class BookingForm(FlaskForm):
    seats = IntegerField('Number of Seats', validators=[DataRequired()])
    submit = SubmitField('Book')

# Routes
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT  FROM users WHERE email = %s",
            (form.email.data,)
        )
        user = cursor.fetchone()
        conn.close()
        if user and user[2] == form.password.data:
            session['user_id'] = user[0]
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password.', 'danger')
    return render_template('login.', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (email, password) VALUES (%s, %s)",
            (form.email.data, form.password.data)
        )
        conn.commit()
        conn.close()
        flash('Registration successful!', 'success')
        return redirect(url_for('login'))
    return render_template('register.', form=form)

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.')

@app.route('/search', methods=['GET', 'POST'])
def search():
    form = SearchForm()
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT DISTINCT source FROM buses")
    sources = [row[0] for row in cursor.fetchall()]
    cursor.execute("SELECT DISTINCT destination FROM buses")
    destinations = [row[0] for row in cursor.fetchall()]
    conn.close()
    form.source.choices = [(source, source) for source in sources]
    form.destination.choices = [(destination, destination) for destination in destinations]
    if form.validate_on_submit():
        buses = get_buses(form.source.data, form.destination.data, form.date.data)
        return render_template('search_results.', buses=buses, form=form)
    return render_template('search.', form=form)

@app.route('/bus/<bus_id>')
def bus_details(bus_id):
    bus = get_bus_details(bus_id)
    form = BookingForm()
    return render_template('bus_details.', bus=bus, form=form)

@app.route('/book/<bus_id>', methods=['POST'])
def book(bus_id):
    form = BookingForm()
    if form.validate_on_submit():
        if 'user_id' in session:
            book_ticket(bus_id, session['user_id'], form.seats.data)
            flash('Ticket booked successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Please login to book a ticket.', 'danger')
            return redirect(url_for('login'))
    return redirect(url_for('bus_details', bus_id=bus_id))

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Logout successful!', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)