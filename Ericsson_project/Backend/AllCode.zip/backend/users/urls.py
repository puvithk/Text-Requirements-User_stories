from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.UserRegistrationView.as_view()),
    path('login/', views.UserLoginView.as_view()),
    path('<int:pk>/', views.UserDetailView.as_view()),
    path('me/', views.UserMeView.as_view()),
]


##