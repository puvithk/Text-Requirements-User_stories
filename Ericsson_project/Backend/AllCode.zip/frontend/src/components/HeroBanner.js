import React from 'react';
import { Grid, Typography, Button, Box } from '@mui/material';
import busImage from '../assets/bus.jpg';

const HeroBanner = () => {
  return (
    <Grid container justifyContent="center" alignItems="center" mt={4} mb={4}>
      <Grid item xs={12} md={6}>
        <Typography variant="h2" gutterBottom>
          Your Journey Starts Here
        </Typography>
        <Typography variant="body1" gutterBottom>
          Find the perfect bus for your next trip with our easy-to-use platform.
        </Typography>
        <Button variant="contained" component={Link} to="/search">
          Search Buses
        </Button>
      </Grid>
      <Grid item xs={12} md={6}>
        <Box
          sx={{
            backgroundImage: url(${busImage}),
            backgroundSize: 'cover',
            height: 300,
            borderRadius: 4,
          }}
        />
      </Grid>
    </Grid>
  );
};

export default HeroBanner;


##