from flask import Flask, request, ify
from flask_jwt_extended import JWTManager, create_access_token, jwt_required
from flask_sqlalchemy import SQLAlchemy
import stripe

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://user:password@host:port/database"
app.config["JWT_SECRET_KEY"] = "your_secret_key"
app.config["STRIPE_SECRET_KEY"] = "sk_test_YOUR_STRIPE_SECRET_KEY"

db = SQLAlchemy(app)
jwt = JWTManager(app)

stripe.api_key = app.config["STRIPE_SECRET_KEY"]

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

class Bus(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    operator = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    arrival_time = db.Column(db.DateTime, nullable=False)
    bus_type = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    seat_availability = db.Column(db.Integer, nullable=False)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    bus_id = db.Column(db.Integer, db.ForeignKey("bus.id"), nullable=False)
    seats = db.Column(db.String(100), nullable=False)
    passenger_name = db.Column(db.String(100), nullable=False)
    passenger_phone = db.Column(db.String(20), nullable=False)
    payment_id = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(50), nullable=False, default="Pending")

@app.route("/register", methods=["POST"])
def register():
    data = request.get_()
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return ify({"message": "Email and password are required"}), 400

    user = User(email=email, password=password)
    db.session.add(user)
    db.session.commit()

    return ify({"message": "User registered successfully"}), 201

@app.route("/login", methods=["POST"])
def login():
    data = request.get_()
    email = data.get("email")
    password = data.get("password")

    if not email or not password:
        return ify({"message": "Email and password are required"}), 400

    user = User.query.filter_by(email=email).first()

    if not user or not user.check_password(password):
        return ify({"message": "Invalid credentials"}), 401

    access_token = create_access_token(identity=user.id)
    return ify({"access_token": access_token}), 200

@app.route("/buses", methods=["GET"])
def get_buses():
    source = request.args.get("source")
    destination = request.args.get("destination")
    departure_date = request.args.get("departure_date")

    buses = Bus.query.filter_by(source=source, destination=destination).all()

    if departure_date:
        buses = [bus for bus in buses if bus.departure_time.strftime("%Y-%m-%d") == departure_date]

    return ify([bus.to_dict() for bus in buses]), 200

@app.route("/buses/<int:bus_id>", methods=["GET"])
def get_bus(bus_id):
    bus = Bus.query.get_or_404(bus_id)
    return ify(bus.to_dict()), 200

@app.route("/bookings", methods=["POST"])
@jwt_required()
def create_booking():
    data = request.get_()
    user_id = get_jwt_identity()
    bus_id = data.get("bus_id")
    seats = data.get("seats")
    passenger_name = data.get("passenger_name")
    passenger_phone = data.get("passenger_phone")

    if not bus_id or not seats or not passenger_name or not passenger_phone:
        return ify({"message": "Bus ID, seats, passenger name, and phone are required"}), 400

    bus = Bus.query.get_or_404(bus_id)

    if bus.seat_availability < len(seats.split(",")):
        return ify({"message": "Insufficient seats available"}), 400

    try:
        payment_intent = stripe.PaymentIntent.create(
            amount=int(bus.price  len(seats.split(","))  100),
            currency="usd",
            automatic_payment_methods={"enabled": True},
        )

        booking = Booking(
            user_id=user_id,
            bus_id=bus_id,
            seats=seats,
            passenger_name=passenger_name,
            passenger_phone=passenger_phone,
            payment_id=payment_intent.client_secret,
        )
        db.session.add(booking)
        db.session.commit()

        return ify({"client_secret": payment_intent.client_secret}), 201

    except Exception as e:
        return ify({"message": str(e)}), 500

@app.route("/bookings/<int:booking_id>", methods=["GET"])
@jwt_required()
def get_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    return ify(booking.to_dict()), 200

@app.route("/bookings/<int:booking_id>", methods=["PUT"])
@jwt_required()
def update_booking(booking_id):
    data = request.get_()
    booking = Booking.query.get_or_404(booking_id)

    if booking.user_id != get_jwt_identity():
        return ify({"message": "Unauthorized"}), 401

    booking.status = data.get("status")
    db.session.commit()

    return ify({"message": "Booking updated successfully"}), 200

@app.route("/bookings/<int:booking_id>", methods=["DELETE"])
@jwt_required()
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)

    if booking.user_id != get_jwt_identity():
        return ify({"message": "Unauthorized"}), 401

    db.session.delete(booking)
    db.session.commit()

    return ify({"message": "Booking cancelled successfully"}), 204

class UserSchema(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "email": self.email,
        }

class BusSchema(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    operator = db.Column(db.String(100), nullable=False)
    source = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    arrival_time = db.Column(db.DateTime, nullable=False)
    bus_type = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    seat_availability = db.Column(db.Integer, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "operator": self.operator,
            "source": self.source,
            "destination": self.destination,
            "departure_time": self.departure_time.strftime("%Y-%m-%d %H:%M:%S"),
            "arrival_time": self.arrival_time.strftime("%Y-%m-%d %H:%M:%S"),
            "bus_type": self.bus_type,
            "price": self.price,
            "seat_availability": self.seat_availability,
        }

class BookingSchema(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    bus_id = db.Column(db.Integer, db.ForeignKey("bus.id"), nullable=False)
    seats = db.Column(db.String(100), nullable=False)
    passenger_name = db.Column(db.String(100), nullable=False)
    passenger_phone = db.Column(db.String(20), nullable=False)
    payment_id = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(50), nullable=False, default="Pending")

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "bus_id": self.bus_id,
            "seats": self.seats,
            "passenger_name": self.passenger_name,
            "passenger_phone": self.passenger_phone,
            "payment_id": self.payment_id,
            "status": self.status,
        }

if __name__ == "__main__":
    db.create_all()
    app.run(debug=True)


##