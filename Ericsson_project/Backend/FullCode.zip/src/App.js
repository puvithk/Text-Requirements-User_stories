import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import SearchPage from './components/SearchPage';
import BusDetailsPage from './components/BusDetailsPage';
import AccountManagementPage from './components/AccountManagementPage';
import CustomerSupportPage from './components/CustomerSupportPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/search" element={<SearchPage />} />
      <Route path="/bus/:busId" element={<BusDetailsPage />} />
      <Route path="/account" element={<AccountManagementPage />} />
      <Route path="/support" element={<CustomerSupportPage />} />
    </Routes>
  );
}

export default App;


##