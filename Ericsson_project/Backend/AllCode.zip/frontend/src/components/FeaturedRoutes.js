import React, { useState, useEffect } from 'react';
import { Grid, Card, CardContent, Typography, CardMedia } from '@mui/material';
import axios from 'axios';

const FeaturedRoutes = () => {
  const [featuredRoutes, setFeaturedRoutes] = useState([]);

  useEffect(() => {
    const fetchFeaturedRoutes = async () => {
      try {
        const response = await axios.get('/api/buses/');
        setFeaturedRoutes(response.data.slice(0, 3)); // Get the first 3 routes
      } catch (error) {
        console.error('Error fetching featured routes:', error);
      }
    };

    fetchFeaturedRoutes();
  }, []);

  return (
    <Grid container spacing={4}>
      {featuredRoutes.map((route) => (
        <Grid item xs={12} md={4} key={route.id}>
          <Card>
            <CardMedia
              component="img"
              height="140"
              image={route.operator.logo}
              alt={route.operator.name}
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                {route.operator.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {route.route.source.name} to {route.route.destination.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Departure: {new Date(route.departure_time).toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Price: ${route.price}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default FeaturedRoutes;


##