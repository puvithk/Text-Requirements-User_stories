import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Avatar from '@material-ui/core/Avatar';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(8, 0),
  },
  container: {
    maxWidth: 960,
    margin: '0 auto',
  },
  card: {
    display: 'flex',
  },
  details: {
    display: 'flex',
    flexDirection: 'column',
  },
  content: {
    flex: '1 0 auto',
  },
  cover: {
    width: 150,
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
}));

function Testimonials() {
  const classes = useStyles();

  const testimonials = [
    {
      name: 'John Doe',
      avatar: 'https://images.unsplash.com/photo-1535713875941-a3d294897132?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80',
      testimonial: 'I had a great experience booking my bus ticket on this platform. The process was easy and the bus was comfortable.',
    },
    {
      name: 'Jane Smith',
      avatar: 'https://images.unsplash.com/photo-1529665253569-6d01c0eaf7b6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80',
      testimonial: 'I was impressed with the customer support. They were very helpful and resolved my issue quickly.',
    },
  ];

  return (
    <div className={classes.root}>
      <div className={classes.container}>
        <Typography variant="h4" gutterBottom>
          Testimonials
        </Typography>
        <Grid container spacing={4}>
          {testimonials.map((testimonial) => (
            <Grid item key={testimonial.name} xs={12} sm={6} md={4}>
              <Card className={classes.card}>
                <div className={classes.details}>
                  <CardContent className={classes.content}>
                    <Typography component="h5" variant="h5">
                      {testimonial.name}
                    </Typography>
                    <Typography variant="body2" color="textSecondary">
                      {testimonial.testimonial}
                    </Typography>
                  </CardContent>
                  <div>
                    <Avatar
                      alt={testimonial.name}
                      src={testimonial.avatar}
                      className={classes.avatar}
                    />
                  </div>
                </div>
              </Card>
            </Grid>
          ))}
        </Grid>
      </div>
    </div>
  );
}

export default Testimonials;


##