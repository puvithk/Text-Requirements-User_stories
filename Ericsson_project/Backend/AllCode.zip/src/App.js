import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css';

function App() {
  const [users, setUsers] = useState([]);
  const [token, setToken] = useState(localStorage.getItem('token'));

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get('http://localhost:5000/users', {
          headers: {
            Authorization: Bearer ${token}
          }
        });
        setUsers(response.data);
      } catch (error) {
        console.error(error);
      }
    };

    if (token) {
      fetchUsers();
    }
  }, [token]);

  const handleLogin = async (event) => {
    event.preventDefault();
    const username = event.target.username.value;
    const password = event.target.password.value;

    try {
      const response = await axios.post('http://localhost:5000/login', {
        username,
        password
      });
      setToken(response.data.token);
      localStorage.setItem('token', response.data.token);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem('token');
  };

  return (
    <Router>
      <div className="App">
        <h1>E-commerce Website</h1>
        {!token ? (
          <form onSubmit={handleLogin}>
            <div>
              <label For="username">Username:</label>
              <input type="text" id="username" name="username" />
            </div>
            <div>
              <label For="password">Password:</label>
              <input type="password" id="password" name="password" />
            </div>
            <button type="submit">Login</button>
          </form>
        ) : (
          <div>
            <p>Welcome, {users.find((user) => user.id === 1)?.username}</p>
            <button onClick={handleLogout}>Logout</button>
            <Routes>
              <Route path="/" element={<UserList users={users} />} />
              <Route path="/products" element={<ProductList />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
            </Routes>
          </div>
        )}
      </div>
    </Router>
  );
}

function UserList({ users }) {
  return (
    <div>
      <h2>Users</h2>
      <ul>
        {users.map((user) => (
          <li key={user.id}>{user.username}</li>
        ))}
      </ul>
    </div>
  );
}

function ProductList() {
  return (
    <div>
      <h2>Products</h2>
      {/ Display products here /}
    </div>
  );
}

function Cart() {
  return (
    <div>
      <h2>Cart</h2>
      {/ Display cart items here /}
    </div>
  );
}

function Checkout() {
  return (
    <div>
      <h2>Checkout</h2>
      {/ Display checkout form here /}
    </div>
  );
}

export default App;


##