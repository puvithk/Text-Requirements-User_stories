import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import axios from 'axios';

function App() {
  const [buses, setBuses] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [departureDate, setDepartureDate] = useState('');

  useEffect(() => {
    const fetchBuses = async () => {
      try {
        const response = await axios.get('/buses');
        setBuses(response.data);
      } catch (error) {
        console.error('Error fetching buses:', error);
      }
    };

    const fetchBookings = async () => {
      try {
        const response = await axios.get('/bookings');
        setBookings(response.data);
      } catch (error) {
        console.error('Error fetching bookings:', error);
      }
    };

    const fetchUser = async () => {
      try {
        const response = await axios.get('/user');
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching user:', error);
      }
    };

    fetchBuses();
    fetchBookings();
    fetchUser();
  }, []);

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleDateChange = (event) => {
    setDepartureDate(event.target.value);
  };

  const handleLogout = async () => {
    try {
      await axios.post('/logout');
      setUser(null);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const filteredBuses = buses.filter((bus) => {
    const sourceMatch = bus.source.toLowerCase().includes(searchTerm.toLowerCase());
    const destinationMatch = bus.destination.toLowerCase().includes(searchTerm.toLowerCase());
    const dateMatch = departureDate ? bus.departure_time.startsWith(departureDate) : true;
    return sourceMatch && destinationMatch && dateMatch;
  });

  return (
    <Router>
      <div className="container">
        <header>
          <h1>Online Bus Ticketing</h1>
          {user ? (
            <div>
              <span>Welcome, {user.email}</span>
              <button onClick={handleLogout}>Logout</button>
            </div>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </header>

        <main>
          <Routes>
            <Route path="/" element={<HomePage buses={filteredBuses} />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/bookings" element={<BookingsPage bookings={bookings} />} />
            <Route path="/buses/:busId" element={<BusDetailsPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function HomePage({ buses }) {
  return (
    <div>
      <h2>Available Buses</h2>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search by source or destination"
          value={searchTerm}
          onChange={handleSearchChange}
        />
        <input
          type="date"
          value={departureDate}
          onChange={handleDateChange}
        />
      </div>
      <ul>
        {buses.map((bus) => (
          <li key={bus.id}>
            <Link to={/buses/${bus.id}}>
              {bus.operator} - {bus.source} to {bus.destination}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('/login', { email, password });
      localStorage.setItem('token', response.data.access_token);
      window.location.href = '/';
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label For="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div>
          <label For="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </div>
        <button type="submit">Login</button>
      </form>
      <p>Don't have an account? <Link to="/register">Register</Link></p>
    </div>
  );
}

function RegisterPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('/register', { email, password });
      window.location.href = '/login';
    } catch (error) {
      console.error('Error registering:', error);
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label For="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
          />
        </div>
        <div>
          <label For="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
          />
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

function BookingsPage({ bookings }) {
  return (
    <div>
      <h2>Your Bookings</h2>
      <ul>
        {bookings.map((booking) => (
          <li key={booking.id}>
            Booking ID: {booking.id} - Status: {booking.status}
          </li>
        ))}
      </ul>
    </div>
  );
}

function BusDetailsPage() {
  const [bus, setBus] = useState(null);
  const [seats, setSeats] = useState('');
  const [passengerName, setPassengerName] = useState('');
  const [passengerPhone, setPassengerPhone] = useState('');
  const [clientSecret, setClientSecret] = useState(null);

  const busId = window.location.pathname.split('/').pop();

  useEffect(() => {
    const fetchBus = async () => {
      try {
        const response = await axios.get(/buses/${busId});
        setBus(response.data);
      } catch (error) {
        console.error('Error fetching bus:', error);
      }
    };

    fetchBus();
  }, [busId]);

  const handleSeatsChange = (event) => {
    setSeats(event.target.value);
  };

  const handlePassengerNameChange = (event) => {
    setPassengerName(event.target.value);
  };

  const handlePassengerPhoneChange = (event) => {
    setPassengerPhone(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('/bookings', {
        bus_id: busId,
        seats,
        passenger_name: passengerName,
        passenger_phone: passengerPhone,
      });
      setClientSecret(response.data.client_secret);
    } catch (error) {
      console.error('Error booking:', error);
    }
  };

  return (
    <div>
      <h2>Bus Details</h2>
      {bus && (
        <div>
          <p>Operator: {bus.operator}</p>
          <p>Source: {bus.source}</p>
          <p>Destination: {bus.destination}</p>
          <p>Departure Time: {bus.departure_time}</p>
          <p>Arrival Time: {bus.arrival_time}</p>
          <p>Bus Type: {bus.bus_type}</p>
          <p>Price: {bus.price}</p>
          <p>Seat Availability: {bus.seat_availability}</p>

          <h3>Book Your Seats</h3>
          <form onSubmit={handleSubmit}>
            <div>
              <label For="seats">Seats:</label>
              <input
                type="text"
                id="seats"
                value={seats}
                onChange={handleSeatsChange}
              />
            </div>
            <div>
              <label For="passengerName">Passenger Name:</label>
              <input
                type="text"
                id="passengerName"
                value={passengerName}
                onChange={handlePassengerNameChange}
              />
            </div>
            <div>
              <label For="passengerPhone">Passenger Phone:</label>
              <input
                type="text"
                id="passengerPhone"
                value={passengerPhone}
                onChange={handlePassengerPhoneChange}
              />
            </div>
            <button type="submit">Book Now</button>
          </form>

          {clientSecret && (
            <div>
              <p>
                <iframe
                  src={https://checkout.stripe.com/checkout-session/client-secret=${clientSecret}}
                  style={{ width: '100%', height: '400px' }}
                />
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;


##