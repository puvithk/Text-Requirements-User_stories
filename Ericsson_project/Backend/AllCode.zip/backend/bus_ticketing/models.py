from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    pass

class Operator(models.Model):
    name = models.CharField(max_length=255)
    logo = models.ImageField(upload_to='operator_logos', blank=True)

    def __str__(self):
        return self.name

class Location(models.Model):
    name = models.CharField(max_length=255)
    latitude = models.DecimalField(max_digits=9, decimal_places=6)
    longitude = models.DecimalField(max_digits=9, decimal_places=6)

    def __str__(self):
        return self.name

class Route(models.Model):
    source = models.ForeignKey(Location, on_delete=models.CASCADE, related_name='source_routes')
    destination = models.ForeignKey(Location, on_delete=models.CASCADE, related_name='destination_routes')
    distance = models.FloatField()
    estimated_travel_time = models.DurationField()

    def __str__(self):
        return f"{self.source} to {self.destination}"

class Bus(models.Model):
    operator = models.ForeignKey(Operator, on_delete=models.CASCADE)
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    price = models.DecimalField(max_digits=8, decimal_places=2)
    seat_availability = models.IntegerField()
    amenities = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.operator} - {self.route} - {self.departure_time}"

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    seat_number = models.CharField(max_length=10)
    payment_id = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.user} - {self.bus} - {self.seat_number}"

class Payment(models.Model):
    booking = models.OneToOneField(Booking, on_delete=models.CASCADE)
    payment_method = models.CharField(max_length=255)
    amount = models.DecimalField(max_digits=8, decimal_places=2)
    transaction_id = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.booking} - {self.payment_method} - {self.amount}"


##