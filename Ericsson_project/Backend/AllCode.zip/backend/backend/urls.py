from django.contrib import admin
from django.urls import include, path
from rest_framework import routers
from bus_ticketing import views

router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'operators', views.OperatorViewSet)
router.register(r'locations', views.LocationViewSet)
router.register(r'routes', views.RouteViewSet)
router.register(r'buses', views.BusViewSet)
router.register(r'bookings', views.BookingViewSet)
router.register(r'payments', views.PaymentViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api/login/', views.UserViewSet.as_view({'post': 'login'}), name='login'),
]


##