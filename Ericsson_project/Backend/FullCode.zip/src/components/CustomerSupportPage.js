import React from 'react';
import ContactUs from './ContactUs';
import FAQ from './FAQ';
import SupportTicketSystem from './SupportTicketSystem';

function CustomerSupportPage() {
  return (
    <div>
      <ContactUs />
      <FAQ />
      <SupportTicketSystem />
    </div>
  );
}

export default CustomerSupportPage;


##