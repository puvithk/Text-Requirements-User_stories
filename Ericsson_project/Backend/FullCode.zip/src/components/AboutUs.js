import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(8, 0),
  },
  container: {
    maxWidth: 960,
    margin: '0 auto',
  },
}));

function AboutUs() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <div className={classes.container}>
        <Typography variant="h4" gutterBottom>
          About Us
        </Typography>
        <Typography variant="body1">
          We are a team of passionate individuals dedicated to providing a seamless and convenient bus ticketing experience. Our mission is to connect people with affordable and reliable bus travel options.
        </Typography>
      </div>
    </div>
  );
}

export default AboutUs;


##