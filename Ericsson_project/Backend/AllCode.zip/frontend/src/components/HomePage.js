import React from 'react';
import { Link } from 'react-router-dom';
import { Grid, Typography, Button, Container, Box } from '@mui/material';
import HeroBanner from './HeroBanner';
import FeaturedRoutes from './FeaturedRoutes';
import Testimonials from './Testimonials';
import AboutUs from './AboutUs';

const HomePage = () => {
  return (
    <Container maxWidth="lg">
      <HeroBanner />

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12}>
          <Typography variant="h4" align="center" mb={2}>
            Featured Routes
          </Typography>
        </Grid>
        <FeaturedRoutes />
      </Grid>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12}>
          <Typography variant="h4" align="center" mb={2}>
            What Our Customers Say
          </Typography>
        </Grid>
        <Testimonials />
      </Grid>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12}>
          <Typography variant="h4" align="center" mb={2}>
            About Us
          </Typography>
        </Grid>
        <AboutUs />
      </Grid>

      <Box mt={4} textAlign="center">
        <Button variant="contained" component={Link} to="/search">
          Book Your Next Trip
        </Button>
      </Box>
    </Container>
  );
};

export default HomePage;


##