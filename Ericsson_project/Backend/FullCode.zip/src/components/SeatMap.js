import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
  seat: {
    width: 50,
    height: 50,
    margin: theme.spacing(1),
    borderRadius: 4,
    backgroundColor: '#ccc',
    cursor: 'pointer',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  availableSeat: {
    backgroundColor: '#4CAF50',
  },
  selectedSeat: {
    backgroundColor: '#f44336',
  },
}));

function SeatMap({ seats, handleSeatSelection }) {
  const classes = useStyles();

  const handleSeatClick = (seatId) => {
    handleSeatSelection(seatId);
  };

  return (
    <div className={classes.root}>
      <Grid container spacing={1}>
        {seats.map((seat) => (
          <Grid item key={seat.id} xs={1} sm={1} md={1}>
            <Button
              className={${classes.seat} ${
                seat.available ? classes.availableSeat : ''
              } ${seat.selected ? classes.selectedSeat : ''}}
              onClick={() => handleSeatClick(seat.id)}
              disabled={!seat.available}
            >
              {seat.id}
            </Button>
          </Grid>
        ))}
      </Grid>
    </div>
  );
}

export default SeatMap;


##