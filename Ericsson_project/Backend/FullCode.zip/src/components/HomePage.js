import React from 'react';
import { Link } from 'react-router-dom';
import HeroBanner from './HeroBanner';
import FeaturedRoutes from './FeaturedRoutes';
import Testimonials from './Testimonials';
import AboutUs from './AboutUs';

function HomePage() {
  return (
    <div>
      <HeroBanner />
      <FeaturedRoutes />
      <Testimonials />
      <AboutUs />
      <Link to="/search">Search for Buses</Link>
    </div>
  );
}

export default HomePage;


##