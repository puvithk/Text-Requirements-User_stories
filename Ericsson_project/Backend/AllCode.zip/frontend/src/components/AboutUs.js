import React from 'react';
import { Grid, Typography } from '@mui/material';

const AboutUs = () => {
  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <Typography variant="body1">
          We are a team of passionate individuals dedicated to providing a seamless and convenient online bus ticketing experience. Our mission is to connect travelers with reliable and affordable bus services, making it easier than ever to explore the world.
        </Typography>
      </Grid>
    </Grid>
  );
};

export default AboutUs;


##