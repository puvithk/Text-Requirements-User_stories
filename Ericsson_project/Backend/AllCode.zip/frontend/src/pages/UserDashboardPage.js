import React, { useEffect, useState } from 'react';
import axios from 'axios';

function UserDashboardPage() {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/users/me/');
        setUserData(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  if (!userData) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container">
      <h1>User Dashboard</h1>
      <p>Username: {userData.username}</p>
      <p>Email: {userData.email}</p>
      {/ Add other user data and functionality here /}
    </div>
  );
}

export default UserDashboardPage;


##