import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { fetchBusDetails } from '../actions/busActions';
import BusInformation from './BusInformation';
import BookingForm from './BookingForm';

function BusDetailsPage() {
  const { busId } = useParams();
  const bus = useSelector((state) => state.buses.bus);
  const dispatch = useDispatch();
  const [selectedSeats, setSelectedSeats] = useState([]);

  useEffect(() => {
    dispatch(fetchBusDetails(busId));
  }, [busId, dispatch]);

  const handleSeatSelection = (seatId) => {
    if (selectedSeats.includes(seatId)) {
      setSelectedSeats(selectedSeats.filter((id) => id !== seatId));
    } else {
      setSelectedSeats([...selectedSeats, seatId]);
    }
  };

  return (
    <div>
      {bus && (
        <>
          <BusInformation bus={bus} />
          <BookingForm
            bus={bus}
            selectedSeats={selectedSeats}
            handleSeatSelection={handleSeatSelection}
          />
        </>
      )}
    </div>
  );
}

export default BusDetailsPage;


##