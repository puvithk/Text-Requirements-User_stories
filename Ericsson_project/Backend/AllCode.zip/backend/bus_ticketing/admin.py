from django.contrib import admin
from .models import User, Operator, Location, Route, Bus, Booking, Payment

admin.site.register(User)
admin.site.register(Operator)
admin.site.register(Location)
admin.site.register(Route)
admin.site.register(Bus)
admin.site.register(Booking)
admin.site.register(Payment)


##