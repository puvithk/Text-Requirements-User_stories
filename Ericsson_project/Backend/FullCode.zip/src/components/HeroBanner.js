import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: '#f5f5f5',
    padding: theme.spacing(8, 0),
  },
  container: {
    maxWidth: 960,
    margin: '0 auto',
    textAlign: 'center',
  },
  title: {
    marginBottom: theme.spacing(4),
  },
  button: {
    marginTop: theme.spacing(2),
  },
}));

function HeroBanner() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <div className={classes.container}>
        <Typography variant="h3" className={classes.title}>
          Your Journey Starts Here
        </Typography>
        <Typography variant="body1">
          Find the perfect bus for your next trip.
        </Typography>
        <Button variant="contained" color="primary" className={classes.button}>
          Book Now
        </Button>
      </div>
    </div>
  );
}

export default HeroBanner;


##