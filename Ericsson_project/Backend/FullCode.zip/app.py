from flask import Flask, render_template, request, ify
from flask_cors import CORS
import mysql.connector
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# Database configuration
db_config = {
    'host': os.getenv('DB_HOST'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME')
}

# Database connection
db = mysql.connector.connect(db_config)
cursor = db.cursor()

# Routes
@app.route('/')
def index():
    return render_template('index.')

@app.route('/search', methods=['POST'])
def search():
    source = request.form['source']
    destination = request.form['destination']
    departure_date = request.form['departure_date']

    # Query the database for buses
    query = """
        SELECT b.bus_id, b.operator, r.source, r.destination, r.departure_time, b.price
        FROM buses b
        JOIN routes r ON b.route_id = r.route_id
        WHERE r.source = %s AND r.destination = %s AND r.departure_date = %s
    """
    cursor.execute(query, (source, destination, departure_date))
    buses = cursor.fetchall()

    # Format the results
    bus_data = []
    for bus in buses:
        bus_data.append({
            'bus_id': bus[0],
            'operator': bus[1],
            'source': bus[2],
            'destination': bus[3],
            'departure_time': bus[4],
            'price': bus[5]
        })

    return ify(bus_data)

@app.route('/bus/<bus_id>')
def get_bus_details(bus_id):
    # Query the database for bus details
    query = """
        SELECT b.bus_id, b.operator, r.source, r.destination, r.departure_time, b.price, b.capacity, b.amenities
        FROM buses b
        JOIN routes r ON b.route_id = r.route_id
        WHERE b.bus_id = %s
    """
    cursor.execute(query, (bus_id,))
    bus = cursor.fetchone()

    # Format the results
    bus_details = {
        'bus_id': bus[0],
        'operator': bus[1],
        'source': bus[2],
        'destination': bus[3],
        'departure_time': bus[4],
        'price': bus[5],
        'capacity': bus[6],
        'amenities': bus[7]
    }

    return ify(bus_details)

@app.route('/book', methods=['POST'])
def book():
    bus_id = request.form['bus_id']
    seats = request.form['seats']
    user_id = request.form['user_id']

    # Check seat availability
    query = """
        SELECT capacity - booked_seats
        FROM buses
        WHERE bus_id = %s
    """
    cursor.execute(query, (bus_id,))
    available_seats = cursor.fetchone()[0]

    if int(seats) > available_seats:
        return ify({'error': 'Not enough seats available'}), 400

    # Create a booking
    query = """
        INSERT INTO bookings (bus_id, user_id, seats, booking_date)
        VALUES (%s, %s, %s, NOW())
    """
    cursor.execute(query, (bus_id, user_id, seats))
    db.commit()

    return ify({'message': 'Booking successful'}), 201

if __name__ == '__main__':
    app.run(debug=True)


##