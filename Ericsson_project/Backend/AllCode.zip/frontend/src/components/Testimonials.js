import React from 'react';
import { Grid, Card, CardContent, Typography, Avatar } from '@mui/material';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'John Doe',
      text: 'I had a great experience booking my bus ticket with this platform. The process was smooth and easy, and the bus was comfortable and on time.',
    },
    {
      name: 'Jane Smith',
      text: 'I was impressed with the wide selection of buses and routes available. I found the perfect bus for my needs and the price was very reasonable.',
    },
  ];

  return (
    <Grid container spacing={4}>
      {testimonials.map((testimonial) => (
        <Grid item xs={12} md={6} key={testimonial.name}>
          <Card>
            <CardContent>
              <Typography variant="body1" gutterBottom>
                "{testimonial.text}"
              </Typography>
              <Grid container alignItems="center">
                <Grid item>
                  <Avatar alt={testimonial.name} src="/static/images/avatar.png" />
                </Grid>
                <Grid item ml={1}>
                  <Typography variant="body2">
                    {testimonial.name}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default Testimonials;


##