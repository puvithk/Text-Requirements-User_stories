import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import BusSearchPage from './components/BusSearchPage';
import BookingPage from './components/BookingPage';
import UserProfilePage from './components/UserProfilePage';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/search" element={<BusSearchPage />} />
        <Route path="/booking/:busId" element={<BookingPage />} />
        <Route path="/profile" element={<UserProfilePage />} />
      </Routes>
    </Router>
  );
}

export default App;


##