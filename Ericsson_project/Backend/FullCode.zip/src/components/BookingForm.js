import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  button: {
    backgroundColor: '#007bff',
    color: '#fff',
  },
}));

function BookingForm({ bus, selectedSeats, handleSeatSelection }) {
  const classes = useStyles();
  const [passengerDetails, setPassengerDetails] = useState({
    name: '',
    age: '',
    contact: '',
  });
  const [paymentOption, setPaymentOption] = useState('');

  const handleChange = (event) => {
    setPassengerDetails({
      ...passengerDetails,
      [event.target.name]: event.target.value,
    });
  };

  const handlePaymentOptionChange = (event) => {
    setPaymentOption(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Submit booking details to backend
    console.log('Booking details:', {
      busId: bus.id,
      selectedSeats,
      passengerDetails,
      paymentOption,
    });
  };

  return (
    <form onSubmit={handleSubmit} className={classes.root}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <TextField
            className={classes.formControl}
            label="Passenger Name"
            name="name"
            value={passengerDetails.name}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            className={classes.formControl}
            label="Passenger Age"
            name="age"
            value={passengerDetails.age}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField
            className={classes.formControl}
            label="Contact Number"
            name="contact"
            value={passengerDetails.contact}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <Select
            className={classes.formControl}
            label="Payment Option"
            value={paymentOption}
            onChange={handlePaymentOptionChange}
          >
            <MenuItem value="creditCard">Credit Card</MenuItem>
            <MenuItem value="debitCard">Debit Card</MenuItem>
            <MenuItem value="netBanking">Net Banking</MenuItem>
          </Select>
        </Grid>
        <Grid item xs={12}>
          <Button
            className={classes.button}
            variant="contained"
            type="submit"
            fullWidth
          >
            Confirm Booking
          </Button>
        </Grid>
      </Grid>
    </form>
  );
}

export default BookingForm;


##