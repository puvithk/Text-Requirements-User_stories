import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Grid, Typography, TextField, Button, Container, Box, Select, MenuItem, FormControl, InputLabel, FormHelperText } from '@mui/material';
import axios from 'axios';

const BusSearchPage = () => {
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [departureDate, setDepartureDate] = useState('');
  const [availableBuses, setAvailableBuses] = useState([]);
  const [locations, setLocations] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        const response = await axios.get('/api/locations/');
        setLocations(response.data);
      } catch (error) {
        console.error('Error fetching locations:', error);
      }
    };

    fetchLocations();
  }, []);

  const handleSearch = async () => {
    try {
      const response = await axios.get('/api/buses/search/', {
        params: {
          source,
          destination,
          departure_date: departureDate,
        },
      });
      setAvailableBuses(response.data);
    } catch (error) {
      console.error('Error searching buses:', error);
    }
  };

  const handleBusClick = (busId) => {
    navigate(/booking/${busId});
  };

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" align="center" mt={4} mb={2}>
        Search for Buses
      </Typography>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth>
            <InputLabel id="source-select-label">Source</InputLabel>
            <Select
              labelId="source-select-label"
              id="source-select"
              value={source}
              onChange={(e) => setSource(e.target.value)}
            >
              {locations.map((location) => (
                <MenuItem key={location.id} value={location.name}>
                  {location.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} md={6}>
          <FormControl fullWidth>
            <InputLabel id="destination-select-label">Destination</InputLabel>
            <Select
              labelId="destination-select-label"
              id="destination-select"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
            >
              {locations.map((location) => (
                <MenuItem key={location.id} value={location.name}>
                  {location.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            label="Departure Date"
            type="date"
            value={departureDate}
            onChange={(e) => setDepartureDate(e.target.value)}
          />
        </Grid>
        <Grid item xs={12} md={6}>
          <Button variant="contained" onClick={handleSearch}>
            Search
          </Button>
        </Grid>
      </Grid>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12}>
          <Typography variant="h5" align="center" mb={2}>
            Available Buses
          </Typography>
        </Grid>
        {availableBuses.length > 0 ? (
          availableBuses.map((bus) => (
            <Grid item xs={12} md={4} key={bus.id}>
              <Card>
                <CardContent>
                  <Typography gutterBottom variant="h6" component="div">
                    {bus.operator.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {bus.route.source.name} to {bus.route.destination.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Departure: {new Date(bus.departure_time).toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Arrival: {new Date(bus.arrival_time).toLocaleString()}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Price: ${bus.price}
                  </Typography>
                  <Button variant="contained" onClick={() => handleBusClick(bus.id)}>
                    Book Now
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))
        ) : (
          <Grid item xs={12}>
            <Typography variant="body1" align="center">
              No buses found for the selected criteria.
            </Typography>
          </Grid>
        )}
      </Grid>
    </Container>
  );
};

export default BusSearchPage;


##