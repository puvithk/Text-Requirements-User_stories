import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ShoppingCartPage() {
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get('/api/cart/');
        setCartItems(response.data);
      } catch (error) {
        console.error('Error fetching cart items:', error);
      }
    };

    fetchCartItems();
  }, []);

  return (
    <div className="container">
      <h1>Shopping Cart</h1>
      <table>
        <thead>
          <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {cartItems.map((item) => (
            <tr key={item.productId}>
              <td>{item.product.name}</td>
              <td>{item.quantity}</td>
              <td>${item.product.price  item.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p>Total: ${cartItems.reduce((total, item) => total + item.product.price  item.quantity, 0)}</p>
      <button>Checkout</button>
    </div>
  );
}

export default ShoppingCartPage;


##