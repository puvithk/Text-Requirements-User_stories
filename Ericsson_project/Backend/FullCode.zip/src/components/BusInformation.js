import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import SeatMap from './SeatMap';

const useStyles = makeStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
  title: {
    marginBottom: theme.spacing(2),
  },
  list: {
    marginBottom: theme.spacing(2),
  },
}));

function BusInformation({ bus }) {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Typography variant="h4" className={classes.title}>
        Bus Information
      </Typography>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6">Bus Operator</Typography>
          <Typography>{bus.operator}</Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6">Route</Typography>
          <Typography>
            {bus.departureCity} to {bus.arrivalCity}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6">Schedule</Typography>
          <Typography>
            Departure: {bus.departureTime}
          </Typography>
          <Typography>
            Arrival: {bus.arrivalTime}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6">Amenities</Typography>
          <List className={classes.list}>
            {bus.amenities.map((amenity) => (
              <ListItem key={amenity}>
                <ListItemText primary={amenity} />
              </ListItem>
            ))}
          </List>
        </Grid>
        <Grid item xs={12}>
          <Typography variant="h6">Seat Map</Typography>
          <SeatMap seats={bus.seats} />
        </Grid>
      </Grid>
    </div>
  );
}

export default BusInformation;


##