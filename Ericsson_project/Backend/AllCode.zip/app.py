from flask import Flask, request, ify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_cors import CORS
import bcrypt
import jwt
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URI')
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
db = SQLAlchemy(app)
ma = Marshmallow(app)
CORS(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

class UserSchema(ma.Schema):
    class Meta:
        fields = ('id', 'username', 'email')

user_schema = UserSchema()
users_schema = UserSchema(many=True)

@app.route('/users', methods=['GET'])
def get_users():
    all_users = User.query.all()
    result = users_schema.dump(all_users)
    return ify(result)

@app.route('/users/<id>', methods=['GET'])
def get_user(id):
    user = User.query.get(id)
    if user:
        result = user_schema.dump(user)
        return ify(result)
    else:
        return ify({'message': 'User not found'}), 404

@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    if not username or not email or not password:
        return ify({'message': 'Missing required fields'}), 400

    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        return ify({'message': 'Username already exists'}), 400

    existing_user = User.query.filter_by(email=email).first()
    if existing_user:
        return ify({'message': 'Email already exists'}), 400

    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    new_user = User(username=username, email=email, password=hashed_password)
    db.session.add(new_user)
    db.session.commit()

    return ify({'message': 'User created successfully'}), 201

@app.route('/users/<id>', methods=['PUT'])
def update_user(id):
    user = User.query.get(id)
    if user:
        data = request.get_()
        user.username = data.get('username')
        user.email = data.get('email')
        if data.get('password'):
            user.password = bcrypt.hashpw(data.get('password').encode(), bcrypt.gensalt()).decode()
        db.session.commit()
        return ify({'message': 'User updated successfully'}), 200
    else:
        return ify({'message': 'User not found'}), 404

@app.route('/users/<id>', methods=['DELETE'])
def delete_user(id):
    user = User.query.get(id)
    if user:
        db.session.delete(user)
        db.session.commit()
        return ify({'message': 'User deleted successfully'}), 200
    else:
        return ify({'message': 'User not found'}), 404

@app.route('/login', methods=['POST'])
def login():
    data = request.get_()
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return ify({'message': 'Missing required fields'}), 400

    user = User.query.filter_by(username=username).first()
    if user:
        if bcrypt.checkpw(password.encode(), user.password.encode()):
            token = jwt.encode({'user_id': user.id}, app.config['SECRET_KEY'])
            return ify({'token': token.decode()}), 200
        else:
            return ify({'message': 'Incorrect password'}), 401
    else:
        return ify({'message': 'User not found'}), 401

if __name__ == '__main__':
    app.run(debug=True)


##