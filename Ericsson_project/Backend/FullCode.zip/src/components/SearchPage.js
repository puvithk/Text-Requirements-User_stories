import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { searchBuses } from '../actions/busActions';
import SearchBar from './SearchBar';
import Filters from './Filters';
import BusListing from './BusListing';

function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({});
  const buses = useSelector((state) => state.buses.buses);
  const dispatch = useDispatch();

  const handleSearch = () => {
    dispatch(searchBuses(searchQuery, filters));
  };

  const handleFilterChange = (filterName, filterValue) => {
    setFilters({ ...filters, [filterName]: filterValue });
  };

  return (
    <div>
      <SearchBar
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        handleSearch={handleSearch}
      />
      <Filters filters={filters} handleFilterChange={handleFilterChange} />
      <BusListing buses={buses} />
    </div>
  );
}

export default SearchPage;


##