import React from 'react';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    alignItems: 'center',
    padding: theme.spacing(2),
  },
  textField: {
    flex: 1,
    marginRight: theme.spacing(2),
  },
  button: {
    backgroundColor: '#007bff',
    color: '#fff',
  },
}));

function SearchBar({ searchQuery, setSearchQuery, handleSearch }) {
  const classes = useStyles();

  const handleChange = (event) => {
    setSearchQuery(event.target.value);
  };

  return (
    <div className={classes.root}>
      <TextField
        className={classes.textField}
        label="Search for buses"
        value={searchQuery}
        onChange={handleChange}
        variant="outlined"
        fullWidth
      />
      <Button
        className={classes.button}
        variant="contained"
        onClick={handleSearch}
      >
        Search
      </Button>
    </div>
  );
}

export default SearchBar;


##