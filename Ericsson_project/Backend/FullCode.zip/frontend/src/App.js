import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [buses, setBuses] = useState([]);
  const [selectedBus, setSelectedBus] = useState(null);
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [departureDate, setDepartureDate] = useState('');

  useEffect(() => {
    const fetchBuses = async () => {
      try {
        const response = await axios.post('/search', {
          source,
          destination,
          departureDate,
        });
        setBuses(response.data);
      } catch (error) {
        console.error('Error fetching buses:', error);
      }
    };

    fetchBuses();
  }, [source, destination, departureDate]);

  const handleSearch = async (event) => {
    event.preventDefault();
    await fetchBuses();
  };

  const handleBusSelect = async (busId) => {
    try {
      const response = await axios.get(/bus/${busId});
      setSelectedBus(response.data);
    } catch (error) {
      console.error('Error fetching bus details:', error);
    }
  };

  const handleBook = async () => {
    try {
      const response = await axios.post('/book', {
        bus_id: selectedBus.bus_id,
        seats: 1, // Replace with actual seat selection
        user_id: 1, // Replace with actual user ID
      });
      alert(response.data.message);
    } catch (error) {
      alert(error.response.data.error);
    }
  };

  return (
    <div className="App">
      <h1>Online Bus Ticketing</h1>
      <form onSubmit={handleSearch}>
        <div>
          <label For="source">Source:</label>
          <input
            type="text"
            id="source"
            value={source}
            onChange={(e) => setSource(e.target.value)}
          />
        </div>
        <div>
          <label For="destination">Destination:</label>
          <input
            type="text"
            id="destination"
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
          />
        </div>
        <div>
          <label For="departureDate">Departure Date:</label>
          <input
            type="date"
            id="departureDate"
            value={departureDate}
            onChange={(e) => setDepartureDate(e.target.value)}
          />
        </div>
        <button type="submit">Search</button>
      </form>

      <h2>Available Buses:</h2>
      <ul>
        {buses.map((bus) => (
          <li key={bus.bus_id}>
            <button onClick={() => handleBusSelect(bus.bus_id)}>
              {bus.operator} - {bus.source} to {bus.destination}
            </button>
          </li>
        ))}
      </ul>

      {selectedBus && (
        <div>
          <h2>Bus Details:</h2>
          <p>Operator: {selectedBus.operator}</p>
          <p>Route: {selectedBus.source} to {selectedBus.destination}</p>
          <p>Departure Time: {selectedBus.departure_time}</p>
          <p>Price: {selectedBus.price}</p>
          <p>Capacity: {selectedBus.capacity}</p>
          <p>Amenities: {selectedBus.amenities.join(', ')}</p>
          <button onClick={handleBook}>Book Now</button>
        </div>
      )}
    </div>
  );
}

export default App;


##