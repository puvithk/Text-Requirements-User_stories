import React from 'react';
import Profile from './Profile';
import BookingHistory from './BookingHistory';
import PaymentMethods from './PaymentMethods';

function AccountManagementPage() {
  return (
    <div>
      <Profile />
      <BookingHistory />
      <PaymentMethods />
    </div>
  );
}

export default AccountManagementPage;


##