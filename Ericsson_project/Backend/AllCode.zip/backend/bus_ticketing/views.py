from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from .models import User, Operator, Location, Route, Bus, Booking, Payment
from .serializers import UserSerializer, OperatorSerializer, LocationSerializer, RouteSerializer, BusSerializer, BookingSerializer, PaymentSerializer
from django.shortcuts import get_object_or_404
from django.contrib.auth import authenticate
from django.contrib.auth.models import update_last_login
from django.utils.timezone import now
import stripe

stripe.api_key = settings.STRIPE_SECRET_KEY

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer

    @action(detail=False, methods=['POST'])
    def login(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            update_last_login(None, user)
            serializer = UserSerializer(user)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

class OperatorViewSet(viewsets.ModelViewSet):
    queryset = Operator.objects.all()
    serializer_class = OperatorSerializer

class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer

class RouteViewSet(viewsets.ModelViewSet):
    queryset = Route.objects.all()
    serializer_class = RouteSerializer

class BusViewSet(viewsets.ModelViewSet):
    queryset = Bus.objects.all()
    serializer_class = BusSerializer

    @action(detail=False, methods=['GET'])
    def search(self, request):
        source = request.query_params.get('source')
        destination = request.query_params.get('destination')
        departure_date = request.query_params.get('departure_date')

        if source and destination and departure_date:
            source_location = get_object_or_404(Location, name=source)
            destination_location = get_object_or_404(Location, name=destination)
            buses = Bus.objects.filter(
                route__source=source_location,
                route__destination=destination_location,
                departure_time__date=departure_date
            )
            serializer = BusSerializer(buses, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Missing required parameters'}, status=status.HTTP_400_BAD_REQUEST)

class BookingViewSet(viewsets.ModelViewSet):
    queryset = Booking.objects.all()
    serializer_class = BookingSerializer
    permission_classes = [IsAuthenticated]

    def create(self, request):
        serializer = BookingSerializer(data=request.data)
        if serializer.is_valid():
            bus = serializer.validated_data['bus']
            if bus.seat_availability > 0:
                serializer.save(user=request.user)
                bus.seat_availability -= 1
                bus.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response({'error': 'No seats available for this bus'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['POST'])
    def payment(self, request, pk):
        booking = get_object_or_404(Booking, pk=pk)
        amount = booking.bus.price
        try:
            payment_intent = stripe.PaymentIntent.create(
                amount=int(amount  100),
                currency='usd',
                automatic_payment_methods={'enabled': True},
            )
            booking.payment_id = payment_intent.id
            booking.save()
            return Response({'client_secret': payment_intent.client_secret}, status=status.HTTP_200_OK)
        except stripe.error.CardError as e:
            return Response({'error': e._body['error']['message']}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer

    def create(self, request):
        serializer = PaymentSerializer(data=request.data)
        if serializer.is_valid():
            booking = serializer.validated_data['booking']
            payment_intent = stripe.PaymentIntent.retrieve(booking.payment_id)
            if payment_intent.status == 'succeeded':
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response({'error': 'Payment failed'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


##