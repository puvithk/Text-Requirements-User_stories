from django.db import models
from django.contrib.auth import get_user_model
from products.models import Product
from cart.models import CartItem

User = get_user_model()

class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=20, default='pending')
    payment_method = models.CharField(max_length=20, blank=True)
    shipping_address = models.CharField(max_length=255, blank=True)
    tracking_number = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f"Order #{self.id}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

    def save(self, args, kwargs):
        self.price = self.product.price  self.quantity
        super(OrderItem, self).save(args, kwargs)


##