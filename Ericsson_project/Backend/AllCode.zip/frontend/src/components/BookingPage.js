import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Grid, Typography, TextField, Button, Container, Box, Card, CardContent, CardMedia, FormControl, InputLabel, Select, MenuItem, Alert } from '@mui/material';
import axios from 'axios';
import StripeCheckout from 'react-stripe-checkout';

const BookingPage = () => {
  const { busId } = useParams();
  const [bus, setBus] = useState(null);
  const [passengerName, setPassengerName] = useState('');
  const [passengerAge, setPassengerAge] = useState('');
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [paymentIntentClientSecret, setPaymentIntentClientSecret] = useState(null);
  const [paymentError, setPaymentError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBusDetails = async () => {
      try {
        const response = await axios.get(/api/buses/${busId}/);
        setBus(response.data);
      } catch (error) {
        console.error('Error fetching bus details:', error);
      }
    };

    fetchBusDetails();
  }, [busId]);

  const handleSeatSelection = (seatNumber) => {
    if (selectedSeats.includes(seatNumber)) {
      setSelectedSeats(selectedSeats.filter((seat) => seat !== seatNumber));
    } else {
      setSelectedSeats([...selectedSeats, seatNumber]);
    }
  };

  const handlePayment = async (token) => {
    try {
      const response = await axios.post(/api/bookings/${busId}/payment/, {
        token: token.id,
        amount: bus.price,
      });
      setPaymentIntentClientSecret(response.data.client_secret);
    } catch (error) {
      console.error('Error creating payment intent:', error);
      setPaymentError(error.response.data.error);
    }
  };

  const handlePaymentSuccess = () => {
    navigate('/profile');
  };

  const handlePaymentError = (error) => {
    console.error('Payment error:', error);
    setPaymentError(error.message);
  };

  if (!bus) {
    return (
      <Container maxWidth="lg">
        <Typography variant="h5" align="center" mt={4} mb={2}>
          Loading bus details...
        </Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" align="center" mt={4} mb={2}>
        Booking Details
      </Typography>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography gutterBottom variant="h6" component="div">
                {bus.operator.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {bus.route.source.name} to {bus.route.destination.name}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Departure: {new Date(bus.departure_time).toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Arrival: {new Date(bus.arrival_time).toLocaleString()}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Price: ${bus.price}
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Passenger Details
              </Typography>
              <TextField
                fullWidth
                label="Name"
                value={passengerName}
                onChange={(e) => setPassengerName(e.target.value)}
              />
              <TextField
                fullWidth
                label="Age"
                type="number"
                value={passengerAge}
                onChange={(e) => setPassengerAge(e.target.value)}
              />
              <Typography variant="h6" gutterBottom mt={2}>
                Seat Selection
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center' }}>
                {Array.from({ length: bus.seat_availability }, (_, index) => index + 1).map((seatNumber) => (
                  <Button
                    key={seatNumber}
                    variant={selectedSeats.includes(seatNumber) ? 'contained' : 'outlined'}
                    onClick={() => handleSeatSelection(seatNumber)}
                    sx={{ margin: 1 }}
                  >
                    {seatNumber}
                  </Button>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={4} mt={4}>
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            Payment
          </Typography>
          {paymentError && (
            <Alert severity="error">{paymentError}</Alert>
          )}
          {paymentIntentClientSecret && (
            <StripeCheckout
              stripeKey="pk_test_51L000000000000000000000"
              token={handlePayment}
              amount={bus.price  100}
              billingAddress
              shippingAddress
              name="Bus Ticketing"
              description="Bus Ticket Payment"
              panelLabel="Pay Now"
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          )}
          {!paymentIntentClientSecret && (
            <Button variant="contained" onClick={() => handlePayment({ id: 'test_token' })}>
              Pay Now
            </Button>
          )}
        </Grid>
      </Grid>
    </Container>
  );
};

export default BookingPage;


##